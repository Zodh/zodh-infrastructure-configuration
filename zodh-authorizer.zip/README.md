# zodh-authorizer

Este projeto serve para cadastrar, confirmar, autenticar e identificar os clientes.

Para gerar o `zodh-authorizer.zip`, siga os seguintes passos:

1. na raiz do projeto, execute o comando `npm install axios pg aws-sdk`;
2. no diretório `.\zodh-video-processor\` execute o comando `Compress-Archive -Path .\zodh-authorizer\* -DestinationPath .\zodh-infrastructure-configuration\zodh-authorizer.zip`, alocando a lambda function no diretório do terraform;
